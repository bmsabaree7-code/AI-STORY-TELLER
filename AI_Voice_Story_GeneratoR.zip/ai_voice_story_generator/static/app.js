const $ = (id) => document.getElementById(id);
let selectedGenre = 'fantasy';
const form = $('storyForm'), storyText = $('storyText'), notice = $('notice');
function showNotice(message, type='info') { notice.textContent = message; notice.className = `notice show ${type}`; }
function hideNotice() { notice.className = 'notice'; notice.textContent = ''; }
async function requestJSON(url, options={}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function updateCounts() {
  const text = storyText.value;
  $('wordCount').textContent = text.trim() ? text.trim().split(/\s+/).length : 0;
  $('charCount').textContent = text.length;
}
storyText.addEventListener('input', updateCounts);
document.querySelectorAll('.genre-card').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('.genre-card').forEach(b => b.classList.remove('selected'));
  button.classList.add('selected'); selectedGenre = button.dataset.genre;
}));
form.addEventListener('submit', async (event) => {
  event.preventDefault(); hideNotice(); const btn = $('generateBtn'); btn.disabled = true; btn.innerHTML = '<span>✦</span> Creating your story…';
  try {
    const data = await requestJSON('/api/story', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({genre:selectedGenre,hero:$('heroName').value,length:$('length').value})});
    storyText.value = data.story; $('storyLabel').textContent = `${data.hero}'s ${selectedGenre} story`; updateCounts(); $('statusText').textContent = 'Story created'; showNotice('Your story is ready. Edit it freely, then choose a voice to create narration.', 'success');
  } catch (err) { showNotice(err.message, 'error'); }
  finally { btn.disabled = false; btn.innerHTML = '<span>✦</span> Generate my story <span class="button-arrow">↗</span>'; }
});
$('clearBtn').addEventListener('click', () => { storyText.value=''; $('storyLabel').textContent='Untitled story'; $('audioResult').classList.add('hidden'); updateCounts(); hideNotice(); });
$('copyBtn').addEventListener('click', async () => { if (!storyText.value.trim()) return showNotice('There is no story to copy yet.', 'info'); try { await navigator.clipboard.writeText(storyText.value); showNotice('Story copied to clipboard.', 'success'); } catch { storyText.select(); document.execCommand('copy'); showNotice('Story copied.', 'success'); } });
async function loadVoices() {
  const btn = $('refreshVoices'); btn.disabled=true;
  try { const data = await requestJSON('/api/voices'); const select=$('voiceSelect'); select.innerHTML='';
    const groups = {};
    data.voices.forEach(v=>{
      const name = v.group || 'Voices';
      if(!groups[name]){ const g=document.createElement('optgroup'); g.label=name; groups[name]=g; select.appendChild(g); }
      const option=document.createElement('option'); option.value=v.voice_id; option.textContent=v.name; groups[name].appendChild(option);
    });
    if (!data.voices.length) select.innerHTML='<option value="">No voices returned</option>';
    if (data.warning) showNotice(data.warning, 'info');
    else showNotice(`Loaded ${data.voices.length} voices.`, 'success');
  } catch(err) { showNotice(err.message, 'error'); }
  finally {btn.disabled=false;}
}
$('refreshVoices').addEventListener('click', loadVoices);
$('stability').addEventListener('input', e=>$('stabilityValue').textContent=Math.round(Number(e.target.value)*100)+'%');
$('similarity').addEventListener('input', e=>$('similarityValue').textContent=Math.round(Number(e.target.value)*100)+'%');
$('narrateBtn').addEventListener('click', async()=>{
  hideNotice(); if(!storyText.value.trim()) return showNotice('Generate or write a story before creating narration.', 'error');
  const btn=$('narrateBtn');btn.disabled=true;btn.querySelector('strong').textContent='Creating your narration…';
  try { const data=await requestJSON('/api/narrate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:storyText.value,voice_id:$('voiceSelect').value,stability:Number($('stability').value),similarity:Number($('similarity').value)})});
    $('audioPlayer').src=data.audio_url; $('downloadLink').href=data.audio_url; $('downloadLink').download=data.item.filename; $('audioResult').classList.remove('hidden'); $('audioProvider').textContent=`Audio · ${data.provider}`; showNotice(data.note ? `Narration ready. ${data.note}` : `Narration generated with ${data.provider}. Preview it or download it.`, 'success'); await loadHistory(); $('audioResult').scrollIntoView({behavior:'smooth',block:'nearest'});
  } catch(err) {showNotice(err.message,'error');}
  finally {btn.disabled=false;btn.querySelector('strong').textContent='Generate voice narration';}
});
async function loadHistory() {
  const root=$('historyList');
  try {const data=await requestJSON('/api/history'); if(!data.history.length){root.innerHTML='<div class="empty-library"><span>♫</span><div><strong>Your library is waiting</strong><p>Generate your first narration and it will show up here.</p></div></div>';return;}
    root.innerHTML=''; data.history.forEach(item=>{const card=document.createElement('article');card.className='history-card';const icon=document.createElement('div');icon.className='history-icon';icon.textContent='♫';const title=document.createElement('strong');title.textContent=item.title;const meta=document.createElement('small');meta.textContent=`${item.created_at} · ${item.characters} characters`;const link=document.createElement('a');link.href=`/audio/${encodeURIComponent(item.filename)}`;link.download=item.filename;link.textContent='↓ Download audio';card.append(icon,title,meta,link);root.appendChild(card);});
  } catch(err){root.innerHTML='<div class="empty-library">Could not load your library. Refresh and try again.</div>';}
}
$('refreshHistory').addEventListener('click',loadHistory);
document.querySelectorAll('[data-scroll]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.scroll).scrollIntoView({behavior:'smooth'})));
$('helpBtn').addEventListener('click',()=>$('helpModal').classList.remove('hidden'));
$('closeHelp').addEventListener('click',()=>$('helpModal').classList.add('hidden'));
$('helpModal').addEventListener('click',e=>{if(e.target===$('helpModal'))$('helpModal').classList.add('hidden')});
loadVoices(); loadHistory(); updateCounts();
