import base64, io, os, unittest, wave
from unittest import mock
os.environ['DEMO_MODE'] = 'true'
from app import app
from story_engine import generate_story
import tts_service as tts

class StoryEngineTests(unittest.TestCase):
    def test_story_contains_hero(self):
        story = generate_story('fantasy', 'Mira', 'medium')
        self.assertIn('Mira', story)
        self.assertGreater(len(story.split()), 20)
    def test_invalid_genre(self):
        with self.assertRaises(ValueError): generate_story('western', 'Mira', 'short')
    def test_invalid_length(self):
        with self.assertRaises(ValueError): generate_story('fantasy', 'Mira', 'extra')

class FlaskRouteTests(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        self.client = app.test_client()
    def test_home_page(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Stories that sound', response.data)
    def test_health(self):
        response = self.client.get('/api/health')
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json['ok'])
    def test_story_api(self):
        response = self.client.post('/api/story', json={'genre':'mystery','hero':'Kavi','length':'short'})
        self.assertEqual(response.status_code, 200)
        self.assertIn('Kavi', response.json['story'])
    def test_invalid_story_request(self):
        response = self.client.post('/api/story', json={'genre':'unknown','hero':'Kavi','length':'short'})
        self.assertEqual(response.status_code, 400)
    def test_voices_demo(self):
        response = self.client.get('/api/voices')
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json['voices'])
    def test_voices_include_free_voices(self):
        os.environ.pop('ELEVENLABS_API_KEY', None); os.environ.pop('GEMINI_API_KEY', None)
        ids = [v['voice_id'] for v in self.client.get('/api/voices').json['voices']]
        self.assertIn('edge:ta-IN-PallaviNeural', ids)
        self.assertFalse(any(i.startswith('gemini:') for i in ids))
    def test_gemini_voices_appear_with_key(self):
        os.environ['GEMINI_API_KEY'] = 'x'
        try:
            ids = [v['voice_id'] for v in self.client.get('/api/voices').json['voices']]
            self.assertIn('gemini:Kore', ids)
        finally:
            os.environ.pop('GEMINI_API_KEY', None)
    def test_narrate_works_without_any_key(self):
        os.environ.pop('ELEVENLABS_API_KEY', None); os.environ.pop('GEMINI_API_KEY', None)
        fake = {'audio': b'ID3fake', 'provider': 'Microsoft voice', 'ext': 'mp3', 'note': None}
        with mock.patch('app.synthesize', return_value=fake):
            response = self.client.post('/api/narrate', json={'text': 'A test story', 'voice_id': 'demo-rachel'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json['provider'], 'Microsoft voice')
    def test_narrate_empty_text(self):
        self.assertEqual(self.client.post('/api/narrate', json={'text': ''}).status_code, 400)

class FallbackTests(unittest.TestCase):
    def test_elevenlabs_failure_falls_back_to_gemini(self):
        with mock.patch('tts_service.ElevenLabsService.text_to_speech', side_effect=tts.ElevenLabsError('quota')), \
             mock.patch('tts_service.gemini_text_to_speech', return_value=b'RIFFwav'):
            r = tts.synthesize('Hello', 'abc123', api_key='k', gemini_key='g')
        self.assertEqual((r['provider'], r['ext']), ('Google Gemini', 'wav'))
        self.assertIn('ElevenLabs', r['note'])
    def test_no_keys_uses_edge(self):
        with mock.patch('tts_service.edge_text_to_speech', return_value=b'mp3') as edge:
            r = tts.synthesize('Hello', 'demo-rachel')
        self.assertEqual(r['provider'], 'Microsoft voice'); edge.assert_called_once()
    def test_edge_failure_falls_back_to_gtts(self):
        with mock.patch('tts_service.edge_text_to_speech', side_effect=tts.TTSError('403')), \
             mock.patch('tts_service.gtts_text_to_speech', return_value=b'mp3') as g:
            r = tts.synthesize('Hello', 'edge:en-US-AriaNeural')
        self.assertEqual(r['provider'], 'Google voice'); self.assertEqual(g.call_args[0][1], 'en')
    def test_tamil_text_picks_tamil_voice(self):
        with mock.patch('tts_service.edge_text_to_speech', return_value=b'x') as edge:
            tts.synthesize('வணக்கம் உலகம்', '')
        self.assertEqual(edge.call_args[0][1], 'ta-IN-PallaviNeural')
    def test_all_fail_raises(self):
        with mock.patch('tts_service.edge_text_to_speech', side_effect=tts.TTSError('a')), \
             mock.patch('tts_service.gtts_text_to_speech', side_effect=tts.TTSError('b')):
            with self.assertRaises(tts.TTSError): tts.synthesize('Hi', '')

class GeminiTests(unittest.TestCase):
    def _resp(self, status=200, payload=None):
        r = mock.Mock(); r.ok = status < 400; r.status_code = status
        r.json.return_value = payload or {}; r.text = ''
        return r
    def test_pcm_wrapped_as_valid_wav(self):
        pcm = b'\x00\x01' * 2400
        payload = {'candidates': [{'content': {'parts': [{'inlineData': {'mimeType': 'audio/L16;codec=pcm;rate=24000', 'data': base64.b64encode(pcm).decode()}}]}}]}
        with mock.patch('tts_service.requests.post', return_value=self._resp(200, payload)) as post:
            wav_bytes = tts.gemini_text_to_speech('Hello', 'Kore', 'key')
        with wave.open(io.BytesIO(wav_bytes)) as w:
            self.assertEqual((w.getframerate(), w.getnchannels(), w.getsampwidth()), (24000, 1, 2))
            self.assertEqual(w.getnframes(), 2400)
        body = post.call_args.kwargs['json']
        self.assertEqual(body['generationConfig']['responseModalities'], ['AUDIO'])
    def test_unknown_model_tries_next_model(self):
        payload = {'candidates': [{'content': {'parts': [{'inlineData': {'mimeType': 'audio/L16;rate=24000', 'data': base64.b64encode(b'\x00\x00' * 10).decode()}}]}}]}
        responses = [self._resp(404, {'error': {'message': 'model not found'}}), self._resp(200, payload)]
        with mock.patch('tts_service.requests.post', side_effect=responses) as post:
            tts.gemini_text_to_speech('Hi', 'Kore', 'key')
        self.assertEqual(post.call_count, 2)
        self.assertIn('gemini-2.5-flash-preview-tts', post.call_args.args[0])
    def test_bad_key_stops_immediately(self):
        with mock.patch('tts_service.requests.post', return_value=self._resp(403, {'error': {'message': 'denied'}})) as post:
            with self.assertRaises(tts.TTSError): tts.gemini_text_to_speech('Hi', 'Kore', 'bad')
        self.assertEqual(post.call_count, 1)

if __name__ == '__main__': unittest.main(verbosity=2)
