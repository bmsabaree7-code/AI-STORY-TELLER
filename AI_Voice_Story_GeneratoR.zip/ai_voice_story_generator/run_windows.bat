@echo off
cd /d "%~dp0"
echo =============================================
echo   STORYWAVE AI - Voice Story Generator
echo =============================================
where py >nul 2>nul
if %errorlevel%==0 (set PYTHON=py) else (set PYTHON=python)
if not exist .venv ( %PYTHON% -m venv .venv )
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Setup complete. Opening Storywave AI at http://127.0.0.1:5000
python app.py
pause
