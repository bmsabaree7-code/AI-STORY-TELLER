from __future__ import annotations
import os, json, uuid, time
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory
from dotenv import load_dotenv
from story_engine import generate_story
from tts_service import ElevenLabsService, ElevenLabsError, TTSError, FREE_VOICES, GEMINI_VOICES, synthesize

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 1 * 1024 * 1024
OUTPUT_DIR = BASE_DIR / 'outputs'
OUTPUT_DIR.mkdir(exist_ok=True)
HISTORY_FILE = BASE_DIR / 'history.json'
MAX_TEXT_CHARS = int(os.getenv('MAX_TEXT_CHARS', '5000'))
DEMO_MODE = os.getenv('DEMO_MODE', 'true').lower() in {'1', 'true', 'yes', 'on'}


def read_history():
    try:
        data = json.loads(HISTORY_FILE.read_text(encoding='utf-8')) if HISTORY_FILE.exists() else []
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def save_history(item):
    history = [item] + read_history()
    history = history[:20]
    HISTORY_FILE.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding='utf-8')
    return history


@app.get('/')
def index():
    return render_template('index.html', demo_mode=DEMO_MODE)


@app.get('/api/health')
def health():
    return jsonify({'ok': True, 'service': 'AI Voice Story Generator', 'demo_mode': DEMO_MODE,
                    'api_key_configured': bool(os.getenv('ELEVENLABS_API_KEY')),
                    'gemini_key_configured': bool(os.getenv('GEMINI_API_KEY'))})


@app.post('/api/story')
def story_api():
    payload = request.get_json(silent=True) or {}
    genre = str(payload.get('genre', 'fantasy')).strip().lower()
    hero = str(payload.get('hero', 'Alex')).strip()[:40]
    length = str(payload.get('length', 'medium')).strip().lower()
    if not hero:
        return jsonify({'error': 'Please enter a hero name.'}), 400
    try:
        story = generate_story(genre, hero, length)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    return jsonify({'story': story, 'words': len(story.split()), 'genre': genre, 'hero': hero})


@app.get('/api/voices')
def voices_api():
    key = os.getenv('ELEVENLABS_API_KEY', '').strip()
    voices, warning, live = [], None, False
    if key:
        try:
            voices = [dict(v, group='ElevenLabs (your account)') for v in ElevenLabsService(key).list_voices()]
            live = True
        except ElevenLabsError as exc:
            warning = f'ElevenLabs is not connected ({exc}) Free voices are available instead.'
    else:
        warning = 'No ElevenLabs API key found. Free voices are ready to use - no key needed.'
    if os.getenv('GEMINI_API_KEY', '').strip():
        voices = voices + [dict(v) for v in GEMINI_VOICES]
    voices = voices + [dict(v) for v in FREE_VOICES]
    return jsonify({'voices': voices, 'warning': warning, 'elevenlabs': live, 'demo': False})


@app.post('/api/narrate')
def narrate_api():
    payload = request.get_json(silent=True) or {}
    text = str(payload.get('text', '')).strip()
    voice_id = str(payload.get('voice_id', '')).strip()
    if not text:
        return jsonify({'error': 'Write or generate a story before narrating.'}), 400
    if len(text) > MAX_TEXT_CHARS:
        return jsonify({'error': f'Story is too long. Maximum length is {MAX_TEXT_CHARS} characters.'}), 400
    key = os.getenv('ELEVENLABS_API_KEY', '').strip()
    gemini_key = os.getenv('GEMINI_API_KEY', '').strip()
    try:
        result = synthesize(text, voice_id, key, gemini_key=gemini_key,
            stability=float(payload.get('stability', 0.5)),
            similarity=float(payload.get('similarity', 0.75)),
            style=float(payload.get('style', 0.0)))
    except (TTSError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 502
    audio_bytes = result['audio']
    filename = f"story_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}.{result['ext']}"
    (OUTPUT_DIR / filename).write_bytes(audio_bytes)
    item = {'id': uuid.uuid4().hex[:10], 'title': text.splitlines()[0][:60] or 'Untitled story',
            'filename': filename, 'created_at': datetime.now().isoformat(timespec='minutes'),
            'characters': len(text), 'voice_id': voice_id, 'provider': result['provider']}
    save_history(item)
    return jsonify({'audio_url': f'/audio/{filename}', 'item': item, 'bytes': len(audio_bytes),
                    'provider': result['provider'], 'note': result['note']})


@app.get('/api/history')
def history_api():
    return jsonify({'history': read_history()})


@app.get('/audio/<path:filename>')
def audio_file(filename):
    mimetype = 'audio/wav' if filename.lower().endswith('.wav') else 'audio/mpeg'
    return send_from_directory(OUTPUT_DIR, filename, as_attachment=False, mimetype=mimetype)


@app.errorhandler(413)
def too_large(_error):
    return jsonify({'error': 'Request is too large.'}), 413


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.getenv('PORT', '5000')), debug=False)
