"""Minimal ElevenLabs REST client with bounded retries and clear errors."""
import time
import requests

API_BASE = 'https://api.elevenlabs.io/v1'

class ElevenLabsError(RuntimeError):
    pass

class ElevenLabsService:
    def __init__(self, api_key, timeout=35):
        if not api_key:
            raise ElevenLabsError('ElevenLabs API key is missing.')
        self.api_key = api_key
        self.timeout = timeout

    def _headers(self):
        return {'xi-api-key': self.api_key, 'Accept': 'application/json', 'Content-Type': 'application/json'}

    def list_voices(self):
        try:
            response = requests.get(f'{API_BASE}/voices', headers={'xi-api-key': self.api_key}, timeout=self.timeout)
        except requests.RequestException as exc:
            raise ElevenLabsError(f'Could not reach ElevenLabs: {exc}') from exc
        if not response.ok:
            raise ElevenLabsError(self._message(response))
        try:
            items = response.json().get('voices', [])
            return [{'voice_id': v.get('voice_id', ''), 'name': v.get('name', 'Unnamed voice'),
                     'category': v.get('category', 'voice')} for v in items if v.get('voice_id')]
        except (ValueError, AttributeError) as exc:
            raise ElevenLabsError('ElevenLabs returned an unexpected voices response.') from exc

    @staticmethod
    def _message(response):
        try:
            detail = response.json().get('detail', {})
            if isinstance(detail, dict):
                message = detail.get('message') or detail.get('status')
            else:
                message = str(detail)
        except ValueError:
            message = response.text[:200]
        return f'ElevenLabs request failed ({response.status_code}): {message or "Check API key, quota, and permissions."}'

    def text_to_speech(self, text, voice_id, stability=0.5, similarity=0.75, style=0.0):
        for value, name in [(stability, 'stability'), (similarity, 'similarity'), (style, 'style')]:
            if not 0 <= float(value) <= 1:
                raise ValueError(f'{name} must be between 0 and 1.')
        url = f'{API_BASE}/text-to-speech/{voice_id}'
        body = {'text': text, 'model_id': 'eleven_multilingual_v2',
                'voice_settings': {'stability': float(stability), 'similarity_boost': float(similarity), 'style': float(style), 'use_speaker_boost': True}}
        last_error = None
        for attempt in range(3):
            try:
                response = requests.post(url, headers={**self._headers(), 'Accept': 'audio/mpeg'}, json=body, timeout=self.timeout)
                if response.ok and response.content:
                    return response.content
                if response.status_code not in (429, 500, 502, 503, 504):
                    raise ElevenLabsError(self._message(response))
                last_error = ElevenLabsError(self._message(response))
            except requests.RequestException as exc:
                last_error = ElevenLabsError(f'Network error contacting ElevenLabs: {exc}')
            if attempt < 2:
                time.sleep(0.7 * (attempt + 1))
        raise last_error or ElevenLabsError('Narration failed after retries.')


# ---------------------------------------------------------------------------
# Free fallback engines (no API key needed) + automatic provider selection
# ---------------------------------------------------------------------------
import asyncio
import base64
import io
import os
import re
import wave

TTSError = ElevenLabsError  # one error type for every provider

TAMIL_RE = re.compile(r'[\u0B80-\u0BFF]')
DEFAULT_EDGE_EN = 'en-US-AriaNeural'
DEFAULT_EDGE_TA = 'ta-IN-PallaviNeural'

EDGE_GROUP = 'Free · Microsoft voices (no key)'
GTTS_GROUP = 'Free · Google voice (basic)'

FREE_VOICES = [
    {'voice_id': 'edge:en-US-AriaNeural', 'name': 'Aria · English (US) · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:en-US-GuyNeural', 'name': 'Guy · English (US) · Male', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:en-US-JennyNeural', 'name': 'Jenny · English (US) · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:en-GB-SoniaNeural', 'name': 'Sonia · English (UK) · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:en-GB-RyanNeural', 'name': 'Ryan · English (UK) · Male', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:en-IN-NeerjaNeural', 'name': 'Neerja · English (India) · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:en-IN-PrabhatNeural', 'name': 'Prabhat · English (India) · Male', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:ta-IN-PallaviNeural', 'name': 'Pallavi · Tamil · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:ta-IN-ValluvarNeural', 'name': 'Valluvar · Tamil · Male', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:hi-IN-SwaraNeural', 'name': 'Swara · Hindi · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:hi-IN-MadhurNeural', 'name': 'Madhur · Hindi · Male', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:te-IN-ShrutiNeural', 'name': 'Shruti · Telugu · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'edge:ml-IN-SobhanaNeural', 'name': 'Sobhana · Malayalam · Female', 'category': 'free', 'group': EDGE_GROUP},
    {'voice_id': 'gtts:en', 'name': 'Google · English', 'category': 'basic', 'group': GTTS_GROUP},
    {'voice_id': 'gtts:ta', 'name': 'Google · Tamil', 'category': 'basic', 'group': GTTS_GROUP},
    {'voice_id': 'gtts:hi', 'name': 'Google · Hindi', 'category': 'basic', 'group': GTTS_GROUP},
]


def default_edge_voice(text):
    return DEFAULT_EDGE_TA if TAMIL_RE.search(text) else DEFAULT_EDGE_EN


def default_gtts_lang(text):
    return 'ta' if TAMIL_RE.search(text) else 'en'


def edge_text_to_speech(text, voice, timeout=90):
    """Microsoft Edge neural voices via the `edge-tts` package (free, no API key)."""
    try:
        import edge_tts
    except ImportError as exc:
        raise TTSError('edge-tts package is not installed. Run: pip install edge-tts') from exc

    async def _run():
        audio = bytearray()
        communicate = edge_tts.Communicate(text, voice)
        async for chunk in communicate.stream():
            if chunk.get('type') == 'audio':
                audio.extend(chunk['data'])
        return bytes(audio)

    last = None
    for attempt in range(2):
        try:
            data = asyncio.run(asyncio.wait_for(_run(), timeout))
            if data:
                return data
            last = TTSError('Microsoft voice returned empty audio.')
        except Exception as exc:  # network, websocket, 403, timeout...
            last = TTSError(f'Microsoft voice failed: {exc}')
        if attempt == 0:
            time.sleep(0.8)
    raise last


def gtts_text_to_speech(text, lang):
    """Google Translate TTS via the `gTTS` package (free, basic quality, needs internet)."""
    try:
        from gtts import gTTS
    except ImportError as exc:
        raise TTSError('gTTS package is not installed. Run: pip install gTTS') from exc
    try:
        buffer = io.BytesIO()
        gTTS(text=text, lang=lang).write_to_fp(buffer)
        data = buffer.getvalue()
    except Exception as exc:
        raise TTSError(f'Google voice failed: {exc}') from exc
    if not data:
        raise TTSError('Google voice returned empty audio.')
    return data


# --- Google AI Studio (Gemini API) text-to-speech -----------------------------
GEMINI_API_BASE = 'https://generativelanguage.googleapis.com/v1beta'
# Google renames/replaces preview TTS models often, so several are tried in order.
# Override with GEMINI_TTS_MODEL in .env if Google publishes a newer one.
GEMINI_MODELS = ['gemini-3.1-flash-tts-preview', 'gemini-2.5-flash-preview-tts']
GEMINI_GROUP = 'Google AI Studio · Gemini (natural, multilingual)'
GEMINI_VOICES = [
    {'voice_id': f'gemini:{name}', 'name': f'{name} · Gemini', 'category': 'gemini', 'group': GEMINI_GROUP}
    for name in ['Kore', 'Puck', 'Zephyr', 'Charon', 'Fenrir', 'Leda', 'Aoede', 'Sulafat']
]
GEMINI_STYLE_PROMPT = 'Read this story aloud in a warm, expressive storytelling voice:\n\n'


def pcm_to_wav(pcm, rate=24000):
    """Gemini returns raw 16-bit mono PCM; wrap it in a WAV container so browsers can play it."""
    buffer = io.BytesIO()
    with wave.open(buffer, 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(rate)
        wav.writeframes(pcm)
    return buffer.getvalue()


def _google_message(response):
    try:
        return response.json().get('error', {}).get('message') or response.text[:200]
    except ValueError:
        return response.text[:200]


def gemini_text_to_speech(text, voice, api_key, timeout=120):
    """Google AI Studio Gemini TTS (REST, no extra package). Returns WAV bytes."""
    if not api_key:
        raise TTSError('GEMINI_API_KEY is missing.')
    models = []
    for name in [os.getenv('GEMINI_TTS_MODEL', '').strip()] + GEMINI_MODELS:
        if name and name not in models:
            models.append(name)
    body = {
        'contents': [{'parts': [{'text': GEMINI_STYLE_PROMPT + text}]}],
        'generationConfig': {
            'responseModalities': ['AUDIO'],
            'speechConfig': {'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': voice or 'Kore'}}},
        },
    }
    headers = {'x-goog-api-key': api_key, 'Content-Type': 'application/json'}
    last = None
    for model in models:
        url = f'{GEMINI_API_BASE}/models/{model}:generateContent'
        for attempt in range(2):
            try:
                response = requests.post(url, headers=headers, json=body, timeout=timeout)
            except requests.RequestException as exc:
                last = TTSError(f'Network error contacting Gemini: {exc}')
                time.sleep(0.8)
                continue
            if response.ok:
                try:
                    part = response.json()['candidates'][0]['content']['parts'][0]['inlineData']
                    pcm = base64.b64decode(part['data'])
                    match = re.search(r'rate=(\d+)', part.get('mimeType', ''))
                    rate = int(match.group(1)) if match else 24000
                except (KeyError, IndexError, TypeError, ValueError):
                    last = TTSError(f'Gemini ({model}) returned no audio.')
                    time.sleep(0.5)
                    continue  # occasionally the model answers with text only; retry once
                if pcm:
                    return pcm_to_wav(pcm, rate)
                last = TTSError(f'Gemini ({model}) returned empty audio.')
                continue
            message = _google_message(response)
            last = TTSError(f'Gemini request failed ({response.status_code}): {message}')
            if response.status_code in (401, 403) or (response.status_code == 400 and 'API key' in message):
                raise last  # bad key: other models will not help
            if response.status_code == 404:
                break  # model name retired/unknown: try the next model
            if response.status_code not in (429, 500, 502, 503, 504):
                break
            time.sleep(0.8 * (attempt + 1))
    raise last or TTSError('Gemini narration failed.')


def synthesize(text, voice_id='', api_key='', stability=0.5, similarity=0.75, style=0.0, gemini_key=''):
    """Create narration audio. Tries the chosen engine first, then falls back automatically.

    voice_id forms: '<elevenlabs id>' | 'gemini:<voice>' | 'edge:<voice>' | 'gtts:<lang>'
    Returns dict(audio=bytes, provider=str, ext='mp3'|'wav', note=str|None).
    """
    voice_id = (voice_id or '').strip()
    plan = []
    if voice_id.startswith('gemini:') and gemini_key:
        plan.append(('gemini', voice_id[7:]))
    elif voice_id.startswith('edge:'):
        plan.append(('edge', voice_id[5:]))
    elif voice_id.startswith('gtts:'):
        plan.append(('gtts', voice_id[5:]))
    elif voice_id and not voice_id.startswith(('demo-', 'gemini:')) and api_key:
        plan.append(('eleven', voice_id))
    # Then every other available engine, best quality first.
    for engine in ('eleven', 'gemini', 'edge', 'gtts'):
        if any(e == engine for e, _ in plan):
            continue
        if engine == 'eleven':
            continue  # only used when the user explicitly picked an ElevenLabs voice
        if engine == 'gemini' and not gemini_key:
            continue
        plan.append((engine, None))

    names = {'eleven': 'ElevenLabs', 'gemini': 'Google Gemini', 'edge': 'Microsoft voice', 'gtts': 'Google voice'}
    failures = []
    for engine, voice in plan:
        ext = 'mp3'
        try:
            if engine == 'eleven':
                audio = ElevenLabsService(api_key).text_to_speech(text, voice, stability, similarity, style)
            elif engine == 'gemini':
                audio = gemini_text_to_speech(text, voice, gemini_key)
                ext = 'wav'
            elif engine == 'edge':
                audio = edge_text_to_speech(text, voice or default_edge_voice(text))
            else:
                audio = gtts_text_to_speech(text, voice or default_gtts_lang(text))
        except ValueError:
            raise
        except TTSError as exc:
            failures.append(f'{names[engine]}: {exc}')
            continue
        note = f'{failures[0]} → switched to {names[engine]} automatically.' if failures else None
        return {'audio': audio, 'provider': names[engine], 'ext': ext, 'note': note}
    raise TTSError('All voice engines failed. ' + ' | '.join(failures))
