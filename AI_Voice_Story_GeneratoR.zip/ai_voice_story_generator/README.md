# Storywave AI — AI Voice Story Generator

A polished Flask web application for the M.Sc. Computer Science mini-project **AI Voice Story Generator using ElevenLabs AI Tool**. It follows the project report's stated design: genre/hero/length-based story generation, editable story text, ElevenLabs voice listing and text-to-speech, audio playback/download, and a recent narration history (last 20 items).

## Features
- Premium responsive dark interface with story studio, genre cards, editable story canvas, voice controls, audio player, and narration library.
- Five story genres: Fantasy, Adventure, Sci-fi, Mystery, and Bedtime.
- Short, medium, and long story options.
- ElevenLabs voices loaded through the server-side API; voice stability and similarity settings.
- MP3 narration output, browser playback, download link, and history.
- Demo mode for testing story generation/UI without an API key.
- API key is stored server-side in `.env`; it is never placed in browser JavaScript.
- Input validation, character limits, useful error messages, and bounded retry for transient API failures.

## Requirements
- Python 3.9 or later
- Internet access for package installation and live ElevenLabs narration
- ElevenLabs account/API key for real voice listing and audio generation

## Run on Windows
1. Extract the ZIP to a normal folder.
2. Double-click `run_windows.bat` (or run it from Command Prompt).
3. On first run it creates a virtual environment, installs dependencies, and copies `.env.example` to `.env`.
4. Open `http://127.0.0.1:5000` in your browser if it does not open automatically.
5. The app runs in demo mode by default; story generation works without an API key.

## Voice engines (automatic fallback)
Narration never depends on a single service. The app tries the voice you picked first and, if it fails, switches automatically:

| Engine | Key needed? | Quality | Notes |
|---|---|---|---|
| ElevenLabs | `ELEVENLABS_API_KEY` | Premium | Free ElevenLabs plans often block library voices through the API |
| Google AI Studio (Gemini TTS) | `GEMINI_API_KEY` (free key at aistudio.google.com/apikey) | Natural, multilingual incl. Tamil | Output is WAV |
| Microsoft Edge voices (`edge-tts`) | No | Very good, Tamil voices included | Needs internet |
| Google Translate voice (`gTTS`) | No | Basic | Last-resort fallback |

Tamil text automatically selects a Tamil voice when no specific voice is chosen. The stability/similarity sliders apply to ElevenLabs only.

Add keys by editing `.env`, restart the server, and click **Refresh** beside Narrator voice. Do not share `.env`.

## Run on macOS/Linux
```bash
chmod +x run_linux_mac.sh
./run_linux_mac.sh
```
Then open `http://127.0.0.1:5000`.

## Run automated checks
```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

The tests cover routes, story generation, voice listing, and the engine fallback chain using mocked providers. They do **not** call any live TTS service; that requires internet and your keys.

## Project structure
```text
ai_voice_story_generator/
├── app.py                 # Flask routes and application configuration
├── story_engine.py        # Template-driven story generator
├── tts_service.py         # ElevenLabs voice listing and TTS client
├── templates/index.html   # Premium UI
├── static/style.css       # Responsive theme and layout
├── static/app.js          # UI interactions and API calls
├── tests/test_app.py      # Automated tests
├── outputs/               # Generated MP3 files (created at runtime)
├── .env.example           # Safe environment template
├── requirements.txt
├── run_windows.bat
└── run_linux_mac.sh
```

## API endpoints
- `GET /api/health` — service status and key presence (never returns the key)
- `POST /api/story` — generates a story
- `GET /api/voices` — lists live voices, or demo placeholders when no key exists
- `POST /api/narrate` — creates MP3 audio using ElevenLabs
- `GET /api/history` — latest 20 narration records
- `GET /audio/<filename>` — serves a generated MP3

## Notes / limitations
- Story text is produced with templates, not a large language model; similar structures may recur.
- The ElevenLabs API requires internet access and may enforce quotas or rate limits.
- Demo voices are UI placeholders and cannot generate audio.
- This local development app is intended for a student project demonstration; add authentication and deployment hardening before exposing it publicly.
