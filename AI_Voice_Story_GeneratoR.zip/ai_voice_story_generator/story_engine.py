"""Simple template-driven story generator used by the project report."""
import random

GENRES = {'fantasy', 'adventure', 'scifi', 'mystery', 'bedtime'}
LENGTHS = {'short': 1, 'medium': 2, 'long': 3}

STORIES = {
 'fantasy': {
  'setting': ['the moonlit kingdom of Asterfall', 'a hidden forest beyond the silver mountains', 'an ancient library that appeared only at midnight'],
  'object': ['a crystal compass', 'a tiny dragon made of starlight', 'a map written in disappearing ink'],
  'challenge': ['a spell that had stolen every sunrise', 'a bridge guarded by a riddle-speaking giant', 'a shadow that copied every brave thought'],
  'ending': ['the kingdom learned that courage grows when it is shared', 'the lost light returned, brighter than before', 'the smallest act of kindness opened the final gate']},
 'adventure': {
  'setting': ['a jungle island missing from every map', 'a desert railway abandoned a century ago', 'a mountain trail hidden behind a waterfall'],
  'object': ['a weathered compass', 'a coded field journal', 'a brass key wrapped in blue cloth'],
  'challenge': ['a sudden storm cut off the return path', 'a rival expedition reached the pass first', 'the only bridge began to collapse'],
  'ending': ['the team discovered that trust was their greatest treasure', 'the journey home became the beginning of a new expedition', 'the discovery was shared with the whole village']},
 'scifi': {
  'setting': ['the orbital city of Nova-7', 'a research station near a quiet red star', 'a future Chennai connected by sky-trains'],
  'object': ['a memory crystal', 'a tiny repair drone', 'a transmission from an unknown planet'],
  'challenge': ['the station AI began deleting its own memories', 'a solar flare disabled the navigation system', 'the signal predicted an event only minutes away'],
  'ending': ['human intuition and machine logic solved the mystery together', 'the signal became humanity’s first message of peace', 'the crew returned with a new reason to explore']},
 'mystery': {
  'setting': ['an old mansion beside a rain-soaked lake', 'a small town where every clock stopped at nine', 'a railway station that appeared on no timetable'],
  'object': ['a photograph with one face scratched out', 'a silver token marked with three dots', 'a letter dated tomorrow'],
  'challenge': ['every witness remembered a different version of the night', 'the evidence pointed to someone who had vanished years ago', 'the final clue was hidden in plain sight'],
  'ending': ['the truth was revealed, and an old friendship was repaired', 'the case closed with one surprising lesson: details matter', 'the town finally understood the secret it had protected']},
 'bedtime': {
  'setting': ['a peaceful village tucked between soft green hills', 'a little cottage beneath a sky full of stars', 'a garden where fireflies made tiny lanterns'],
  'object': ['a warm golden lantern', 'a sleepy cloud in a glass jar', 'a tiny bell that rang only for kind hearts'],
  'challenge': ['the moon could not find its way home', 'the flowers had forgotten their lullaby', 'a gentle breeze had scattered the stars’ wishes'],
  'ending': ['everyone settled down knowing tomorrow would bring fresh wonder', 'the night grew quiet, safe, and full of dreams', 'kindness lit the way until the whole valley slept']}
}


def generate_story(genre='fantasy', hero='Alex', length='medium'):
    genre, length = genre.lower(), length.lower()
    if genre not in GENRES:
        raise ValueError(f"Unsupported genre. Choose: {', '.join(sorted(GENRES))}.")
    if length not in LENGTHS:
        raise ValueError('Length must be short, medium, or long.')
    hero = (hero or 'Alex').strip()[:40]
    if not hero:
        raise ValueError('Hero name cannot be empty.')
    bank = STORIES[genre]
    # Fixed selection order makes output predictable and tests reproducible.
    setting = random.choice(bank['setting'])
    obj = random.choice(bank['object'])
    challenge = random.choice(bank['challenge'])
    ending = random.choice(bank['ending'])
    paragraphs = [
      f"In {setting}, there lived a curious and determined hero named {hero}. One quiet morning, {hero} discovered {obj}. It seemed ordinary at first, but a faint glow revealed that it carried a secret.",
      f"A message appeared: the only way forward was to face {challenge}. {hero} took a deep breath, gathered a few trusted friends, and followed the clues. The road was difficult, yet every setback taught the group to listen, think carefully, and help one another.",
      f"At the turning point, {hero} noticed a detail everyone else had missed. Instead of choosing the easiest path, {hero} acted with patience and courage. The mystery began to unravel, and the friends worked together to overcome the final obstacle.",
      f"By sunset, {ending}. {hero} returned home wiser than before, carrying not only a remarkable memory but also a lesson: brave choices become stronger when they are guided by kindness. And so a new chapter waited just beyond the horizon."
    ]
    count = LENGTHS[length]
    return '\n\n'.join(paragraphs[:count] if count < 3 else paragraphs)
